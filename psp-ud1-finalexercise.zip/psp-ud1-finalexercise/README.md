## Service and process programming. Final exercise unit 1
<p>In this exercise is required to do a program to manage the enrolment 
process to some courses in a summer camp using JavaFx</p>
<p>Author: Sergio Martí Torregrosa</p>