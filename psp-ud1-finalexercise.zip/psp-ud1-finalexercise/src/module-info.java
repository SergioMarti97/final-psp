module psp.ud.finalexercise {
    //requires kotlin.stdlib;

    requires javafx.controls;
    requires javafx.fxml;

    exports summercampfx.model;

    opens summercampfx;
}